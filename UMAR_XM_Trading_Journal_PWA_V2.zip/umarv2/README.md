# UMAR XM™ Trading Journal V2 Android Project

Advanced offline Android WebView app based on the V1 journal.

## Added in V2
- Equity curve
- Monthly trading calendar
- Trade detail modal with chart screenshot
- APA Strategy checklist
- SMC checklist (BOS, CHOCH/MSS, OB, liquidity, FVG, premium/discount)
- Risk calculator with risk amount and R:R
- Win/loss streak statistics
- Asset and strategy analytics
- Psychology, setup quality, entry/exit/lesson fields
- JSON backup/restore and CSV export
- Local/offline storage

## Build
Open this folder in Android Studio, sync Gradle, then Build > Build APK(s).
The app uses the bundled `app/src/main/assets/index.html`, so it works offline.
